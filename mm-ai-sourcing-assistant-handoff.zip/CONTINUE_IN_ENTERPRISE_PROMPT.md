# Continue This Project In Another ChatGPT/Codex Session

Paste this prompt into the new ChatGPT Enterprise or Codex session:

```text
You are continuing an existing project called "M&M AI Sourcing Assistant".

Important:
- This is an existing implemented project, not a new build.
- Do not rebuild the app from scratch.
- Continue from the current implementation.
- Read PROJECT_HANDOFF.md first.
- Then inspect the codebase before making changes.
- Preserve the demo-only behavior unless I explicitly ask to change it.
- Do not add OpenAI API.
- Do not add any external AI API.
- Do not add real email sending.
- Do not require API keys.
- Do not use the actual Mahindra logo.

Project summary:
M&M AI Sourcing Assistant is a demo-only AI-powered laptop procurement sourcing assistant for a procurement manager. It uses deterministic simulated AI logic, a mock supplier database, supplier scoring, RFQ draft generation, and simulated RFQ email sending.

Demo login:
- Email: procurement.manager@mahindra.com
- Password: any value

Current flow:
Login -> blank laptop requirement form -> supplier recommendation -> select suppliers -> RFQ draft -> edit email -> simulated send -> success popup and sent summary.

Before making changes:
1. Read PROJECT_HANDOFF.md.
2. Read FILE_MANIFEST.md.
3. Inspect package.json and the app routes.
4. Run or verify the build if the task affects code.

Good next tasks:
- Deployment support
- Vercel smoke testing
- Small bug fixes
- UI polish
- Documentation updates
- Adding demo-only features such as quote comparison or supplier response simulation

Guardrails:
- Keep the app demo-only.
- Keep state localStorage-based unless explicitly asked otherwise.
- Keep supplier data fictional.
- Keep email sending simulated only.
- Keep AI behavior deterministic/rule-based unless explicitly asked otherwise.
```
