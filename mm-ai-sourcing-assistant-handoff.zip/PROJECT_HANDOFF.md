# M&M AI Sourcing Assistant - Project Handoff

## Project Name

M&M AI Sourcing Assistant

## Purpose

This is a demo-only AI-powered laptop procurement sourcing assistant prototype. It helps a procurement manager create a laptop sourcing event, match fictional suppliers, generate a professional RFQ draft, and simulate sending RFQ emails.

This prototype does not use OpenAI API, does not use external AI APIs, does not require API keys, and does not send real emails.

## Business Use Case

The prototype demonstrates a procurement workflow for sourcing laptops from enterprise IT suppliers. It is intended for client demos where a procurement manager can see how a simulated AI assistant might reduce manual sourcing effort by structuring requirements, ranking suppliers, and drafting RFQ communication.

## Target User

Primary user: Procurement manager responsible for enterprise laptop procurement.

Demo login:

- Email: `procurement.manager@mahindra.com`
- Password: any value

## Tech Stack

- Next.js App Router
- TypeScript
- React
- Tailwind CSS
- LocalStorage for demo state
- Mock supplier database in TypeScript
- Deterministic simulated AI agent module
- No backend API routes
- No real authentication
- No real email service

## Current App Flow

1. Login page
2. Blank laptop procurement requirement form
3. Simulated AI analysis loading modal
4. Supplier recommendation page
5. Supplier selection for RFQ
6. Simulated RFQ preparation loading modal
7. Editable RFQ email page
8. Simulated email sending loading modal
9. Success popup
10. Sent RFQ summary

## Pages Implemented

- `/` - demo login page
- `/requirements` - laptop procurement requirement form
- `/recommendations` - supplier recommendation and selection page
- `/rfq` - editable RFQ draft and simulated send page

## Features Implemented

- Demo-only login using localStorage
- Blank requirement form after fresh login
- Load Sample Laptop Requirement button
- Required field validation
- Mock supplier database with 10 fictional suppliers
- Deterministic supplier scoring
- AI-style requirement summary
- AI-style supplier recommendation reasons
- Supplier selection validation
- RFQ subject/body generation
- Editable RFQ subject and body
- Simulated RFQ sending
- Sent RFQ log in localStorage
- Logout workflow reset
- Premium animated Mahindra-inspired UI background
- Responsive desktop, tablet, and mobile layout

## Simulated AI Agent

The simulated AI agent lives in `lib/agent/procurementAgent.ts`.

It is deterministic and rule-based. It does not call OpenAI, any external AI API, or any external service.

Agent functions:

- `analyzeRequirement(requirement)`
- `scoreSuppliers(requirement, suppliers)`
- `generateRecommendationReason(requirement, supplier, scoreBreakdown)`
- `generateRFQEmail(requirement, selectedSuppliers, loggedInUserEmail)`

The language is template-generated to feel like an AI procurement assistant, but all results are deterministic.

## Mock Supplier Database

The current mock supplier database is in `data/suppliers.ts`.

It contains exactly 10 fictional laptop suppliers. Each supplier includes:

- id
- name
- email
- location
- service coverage
- laptop types supported
- brands supported
- certifications
- average delivery days
- rating
- risk level
- order capacity
- warranty and support capability
- security capabilities
- past enterprise experience
- price competitiveness
- description

All supplier emails use demo-safe fake domains such as `example.com`.

## Supplier Recommendation Logic

Supplier scoring is deterministic and based on a 100-point scoring model:

- Laptop type/category support: 20 points
- Brand match: 15 points
- Delivery timeline match: 15 points
- Location or service coverage match: 15 points
- Certification match: 15 points
- Rating meets minimum rating: 10 points
- Warranty/support match: 5 points
- Past enterprise experience: 5 points

The recommendation page sorts suppliers from highest score to lowest score and displays the match percentage, fit category, risk badge, supplier details, and AI-style recommendation reason.

## RFQ Draft Generation Logic

RFQ draft generation is handled by `generateRFQEmail` in `lib/agent/procurementAgent.ts`.

It uses:

- latest submitted requirement
- selected suppliers
- logged-in user email as From email

It generates:

- specific RFQ subject
- professional supplier-neutral email body
- AI note explaining that the RFQ was generated from the requirement and supplier capabilities

## Simulated Email Sending

No real emails are sent.

When the user clicks Send RFQ:

- a loading modal is shown
- a local sent log is created in localStorage
- a success popup is displayed
- the sent summary is shown in the RFQ sidebar

The sent log key is `mm-rfq-sent-log`.

## Login and Logout Behavior

Login:

- user enters `procurement.manager@mahindra.com`
- password can be any value
- logged-in email is saved to `mm-sourcing-user`
- user is routed to `/requirements`
- fresh login clears workflow state so the requirement form starts blank

Logout:

- visible in the authenticated header
- clears logged-in user and workflow localStorage keys
- routes back to `/`

Cleared workflow keys:

- `mm-sourcing-user`
- `mm-sourcing-demo-state`
- `mm-laptop-requirement`
- `mm-selected-laptop-suppliers`
- `mm-rfq-sent-log`

## LocalStorage and State Handling

Main localStorage keys:

- `mm-sourcing-user`
- `mm-sourcing-demo-state`
- `mm-laptop-requirement`
- `mm-selected-laptop-suppliers`
- `mm-rfq-sent-log`

The requirement form intentionally starts blank after fresh login. Sample data is only loaded when the user clicks `Load Sample Laptop Requirement`.

## UI/UX Design Approach

The prototype uses a premium enterprise SaaS dashboard style:

- red, white, charcoal grey, and metallic grey palette
- subtle animated branded background
- glass-style cards
- soft shadows
- clear step indicator
- polished loading modals
- responsive layouts for desktop, tablet, and mobile

## Branding Approach

The theme is Mahindra-inspired but does not use the actual Mahindra logo. The app uses a generic icon mark and enterprise red/charcoal visual language.

## Demo-Only Scope

Demo-only behavior includes:

- simulated login
- simulated AI agent
- simulated supplier scoring
- mock suppliers
- simulated RFQ email generation
- simulated email sending
- localStorage-only state

## Not Implemented

- real authentication
- real backend database
- real supplier APIs
- real email delivery
- OpenAI API or external AI API
- file upload
- PDF generation
- supplier response tracking
- approval workflow
- production-grade access control

## Known Limitations

- State is local to the browser using localStorage.
- Refreshing during an active workflow generally preserves submitted workflow data, but a fresh login/logout resets the demo.
- Supplier scoring is deterministic and simplified for demo purposes.
- Legacy helper files `lib/scoring.ts` and `lib/mock-suppliers.ts` remain from early prototype stages. The active supplier recommendation flow uses `data/suppliers.ts` and `lib/agent/procurementAgent.ts`.
- No real integrations exist.

## Future Enhancement Ideas

- Add quote comparison view after simulated supplier responses.
- Add approval routing.
- Add PDF export for RFQ.
- Add supplier response simulation.
- Add analytics dashboard.
- Add configurable scoring weights.
- Add multi-location procurement support.
- Add admin page for editing mock supplier data.

## How To Run Locally

Install dependencies:

```bash
npm install
```

Run development server:

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

This workspace currently includes `pnpm-lock.yaml`, so `pnpm install` and `pnpm dev` also work in pnpm-based environments.

## How To Build

```bash
npm run build
```

This runs the Next.js production build.

## How To Deploy On Vercel

Recommended Vercel settings:

- Framework preset: Next.js
- Install command: `npm install` or Vercel auto-detected package manager
- Build command: `npm run build`
- Output directory: Next.js default
- Environment variables: none required

No API keys are needed.

## What Should Be Done Next

Recommended next steps:

1. Push the clean project to GitHub.
2. Import the GitHub repository into Vercel.
3. Deploy using the default Next.js settings.
4. Run one production smoke test on the deployed URL.
5. Decide whether to keep or remove early legacy helper files after deployment.
